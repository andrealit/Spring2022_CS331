To run this code on the ENGR servers, do the command

python3 main.py
