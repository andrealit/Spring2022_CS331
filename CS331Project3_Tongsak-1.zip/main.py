import numpy as np
import pandas as pd
from string import digits, punctuation

def strip(review):
    # DESCRIPTION: Takes in a string and returns an array words formatted without numbers/punctuation
    # Example: "Wow... Loved this place! 1" -> ['wow' 'loved' 'this' 'place']
    remove_pun = str.maketrans('','', punctuation)
    remove_nums = str.maketrans('','', digits)
    strip = np.array(str(review).translate(remove_pun).translate(remove_nums).lower().split())
    return strip

def read_data():
    # DESCRIPTION: The function reads in a tab-separated text file and names each column and their numerical value
    # Vocab will split the review column into unique words, and will be kept in alphabetical order
    # Training Data Split
    train = np.array(pd.read_csv("trainingSet.txt", sep='\t'))
    test = np.array(pd.read_csv("testSet.txt", sep='\t'))
    trainX, trainY = train.T
    testX, testY = test.T
    vocabulary = np.unique(strip(trainX)) # This line stores each unique word in a list known to the classifier
    t = [strip(x) for x in trainX]
    trainX = np.array(t, dtype=object)
    t = [strip(x) for x in testX]
    testX = np.array(t, dtype=object)
    return (trainX, trainY), (testX, testY), vocabulary

def output_data(bag, label, vocab, processed):
    # DESCRIPTION: The function takes in features and outputs the preprocessed training and testing data
    with open(processed, "w") as output:
        print(*vocab, "classlabel", sep=',', file=output)
        size = bag.shape[0]
        for x in range(size):
            if (np.array_equal(label, [])):
                print(*bag[x], label[x], sep=',', file=output)
            else:
                print(*bag[x], sep=",", file=output)

def accuracy(prediction, labels):
    # DESCRIPTION: This function outputs the accuracy: Number of Correct Predictions / Total Predictions
    # Count the non-zero values (1s) in the array and also store the total
    total = labels.shape[0]
    equal = (prediction == labels)
    same = np.count_nonzero(equal)
    return same / total

class Naive_Bayes_Classifier:
    # DESCRIPTION: Naive Bayes-- a special type of Bayesian network that makes a conditional independence assumption, used for classification

    def start(self, trainedX, trainedY, vocabulary):
        # DESCRIPTION:
        # This function runs every time a new classifier is instantiated.
        self.vocabulary = vocabulary
        self.train_wordbag = self.bag_of_words(trainedX)
        self.pos_pxy, self.neg_pxy = self.word_class(self.train_wordbag, trainedY)

    def bag_of_words(self, data):
        # DESCRIPTION: This function takes in vocabulary and gives back a word set
        num_examples = data.shape[0]
        num_features = self.vocabulary.shape[0]
        set = np.zeros((num_examples, num_features), dtype=int)
        for row_ind in range(num_examples):
            for row_word in data[row_ind]:
                set[row_ind][np.where(row_word==self.vocabulary)]=1
        return set

    def word_class(self, X, Y):
        # DESCRIPTION: This function is used for training, finds the probability of words in the class
        # Apply training features, training labels uniform dirichlet priors simplify to 1
        # P(X = u | Y = v)
        # P(Word = 1 | Class) and P(Word = 0 | Class)
        positive_reviews = X[Y==1]
        negative_reviews = X[Y==0]
        positive_cl, _ = positive_reviews.shape
        negative_cl, _ = negative_reviews.shape
        self.prob_pos = positive_cl / (positive_cl + negative_cl)
        self.prob_neg = negative_cl / (positive_cl + negative_cl)
        positive_num = np.sum(positive_reviews, axis = 0) + 1
        negative_num = np.sum(negative_reviews, axis = 0) + 1
        pos_pxy = positive_num / positive_cl
        neg_pxy = negative_num / negative_cl
        # returns Class = 1 and Class = 0
        return pos_pxy, neg_pxy

    def class_X(self, X, ClassLabel):
        # DESCRIPTION: This is Naive Bayes Classifier, calculates probability of X being in the class (either 1 or 0)
        # P(Class label | Words in document)
        if ClassLabel == "1":
            return np.log(self.prob_pos) + np.sum(X * np.log(self.pos_pxy))
        else:
            return np.log(self.prob_neg) + np.sum(X * np.log(self.neg_pxy))

    def predict_one(self, X):
        # DESCRIPTION: This function will predict probability with one example
        # A document is a review categorized as positive or negative
        # Predict Class = 1 otherwise predict Class = 0
        if self.class_X(X, "1") > self.class_X(X, "0"):
            return 1
        else:
            return 0

    def predict_all(self, X):
        self.test_wordbag = self.bag_of_words(X)
        result = [self.predict_one(x) for x in self.test_wordbag]
        return np.array(result)

if __name__ == '__main__':
    # --------------------------------
    ## Creates result.txt accuracy for training set and test set
    train, test, vocab = read_data()
    training_reviews, training_label = train
    test_reviews, test_label = test
    classifier = Naive_Bayes_Classifier()

    classifier.start(training_reviews, training_label, vocab)

    train_p = classifier.predict_all(training_reviews)
    test_p = classifier.predict_all(test_reviews)
    train_accuracy = accuracy(train_p, training_label)
    test_accuracy = accuracy(test_p, test_label)
    output_data(classifier.train_wordbag, training_label, vocab, "preprocessed_train.txt")
    output_data(classifier.test_wordbag, test_label, vocab, "preprocessed_test.txt")

    with open("results.txt", "w") as results:
        print("===========================", file=results)
        print(f"Training: {train_accuracy :.5%}", file=results)
        print(f"Test: {test_accuracy :.5%}", file=results)
        print("===========================", file=results)
